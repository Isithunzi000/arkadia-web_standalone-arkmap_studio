```
Niespojne kierunki — mapa map_master3
(kierunek po * nie jest wyjsciem / bind bez komendy; skroty i polskie nazwy OK)

17 pokoi do poprawy

=== Rozjazdy team_follow (17) ===
1. #22573  Ard Skellig
   team_follow:  kamiennych stopniach na arene*arena#kamiennych stopniach ku szczytowi klifu*n
   zle:          arena  ->  n

2. #6535  Averland
   team_follow:  ulice*wyjscie
   zle:          wyjscie  ->  n

3. #15491  Averland
   team_follow:  obozu*oboz
   zle:          oboz  ->  e, ne, se, up

4. #24171  Ebino
   team_follow:  wschod*e#wozowni*ne
   zle:          ne  ->  e

5. #14775  Gory Kranca Swiata
   team_follow:  poludnie*s
   zle:          s  ->  nw, przeskocz szczeline

6. #8124  Gory Sine
   team_follow:  zewnatrz*wyjscie#na zewnatrz*wyjscie
   zle:          wyjscie  ->  n, nw, s

7. #15917  Lyria i Rivia
   team_follow:  wyjscie*do wyjscia
   zle:          do wyjscia  ->  w, wyjscie

8. #19734  Lyria i Rivia
   team_follow:  wyjscie*do wyjscia przez otwor
   zle:          do wyjscia przez otwor  ->  down, wyjscie

9. #23137  Polnocna Redania
   team_follow:  w glab otworu*s
   zle:          s  ->  n, otwor

10. #23145  Polnocna Redania
   team_follow:  po schodach na dol*d#przez otwor na gore*otwor#przez otwor na gore*n
   zle:          n  ->  down, otwor

11. #18370  Pustynia Zerrikanska
   team_follow:  do wnetrza wyrwy*d
   zle:          d  ->  w, wyrwa

12. #2835  Tretogor
   team_follow:  schodach*schody
   zle:          schody  ->  n, s, se, sw, up, w

13. #6066  Wissenland
   team_follow:  obozu*oboz
   zle:          oboz  ->  n, ne, s

14. #16389  Wissenland
   team_follow:  16369 powierzchni*gora
   zle:          gora  ->  sw, przejdz przez wneke

15. #22510  Wschodni Mahakam
   team_follow:  przez drzwi na polane*se#przez drzwi na polane*wyjscie
   zle:          se  ->  schodki, wyjscie

16. #8638  Zachodnia Temeria
   team_follow:  drzwi*wnetrza wiezy#wnetrza wiezy*drzwi
   zle:          wnetrza wiezy  ->  ne, drzwi

17. #19725  Zachodnia Temeria
   team_follow:  szalasu*szalas
   zle:          szalas  ->  ne, s, w, dziupla

```
