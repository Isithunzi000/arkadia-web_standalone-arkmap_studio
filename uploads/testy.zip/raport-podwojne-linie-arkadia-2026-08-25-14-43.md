# Raport podwójnych linii wyjść — ArkMap Studio

- Plik: 🌐 online · map_master3.dat
- Wersja aplikacji: v1.49.4
- Data: 2026-08-25T14:43:27.868Z

## Informacja

Podwójne linie dotyczą tylko wyglądu — mapa działa poprawnie, brak wpływu na rozgrywkę.
Auto-naprawa (przycisk „Napraw"): redundantne proste custom lines zostaną usunięte,
przy realnych krzywych po stronie docelowej zostanie dodana pusta custom line.

## Podwójne linie (7)

Pokój #7226 (dir=n → #16210): podwójna linia, domknięcie w #16210 dir=s
Pokój #8123 (dir=n → #8124): podwójna linia, domknięcie w #8124 dir=s
Pokój #9402 (dir=s → #9444): podwójna linia, domknięcie w #9444 dir=n
Pokój #9815 (dir=ne → #9834): podwójna linia, domknięcie w #9834 dir=sw
Pokój #11049 (dir=s → #11045): podwójna linia, domknięcie w #11045 dir=n
Pokój #14668 (dir=sw → #14664): podwójna linia, domknięcie w #14664 dir=ne
Pokój #19198 (dir=n → #19201): podwójna linia, domknięcie w #19201 dir=s
